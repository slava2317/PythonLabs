def send_email(task_title: str):
    print(f"Email has been sent! Task: {task_title}")
